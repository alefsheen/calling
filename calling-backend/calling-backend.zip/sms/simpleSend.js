require("dotenv").config();
const token = process.env.SMS_TOKEN;

const Kavenegar = require("kavenegar");

module.exports = function simpleSend() {
  const api = Kavenegar.KavenegarApi({
    apikey:
      "5832656862344F707059346838316D73476449494C6373492B516D576B304661526C35492F5A4C4F756E343D",
  });
  api.Send(
    {
      message: "خدمات پیام کوتاه کاوه نگار",
      sender: "2000660110",
      receptor: "09156151017",
    },
    function (response, status) {
      console.log(response);
      console.log(status);
    }
  );
};

/*
sample output
{
    "return":
    {
        "status":200,
        "message":"تایید شد"
    },
    "entries": 
    [
        {
            "messageid":8792343,
            "message":"خدمات پیام کوتاه کاوه نگار",
            "status":1,
            "statustext":"در صف ارسال",
            "sender":"10004346",
            "receptor":"09123456789",
            "date":1356619709,
            "cost":120
        },
        {
            "messageid":8792344,
            "message":"خدمات پیام کوتاه کاوه نگار",
            "status":1,
            "statustext":"در صف ارسال",
            "sender":"10004346",
            "receptor":"09367891011",
            "date":1356619709,
            "cost":120
        }
    ]
}
*/
