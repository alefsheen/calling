var Kavenegar = require("kavenegar");
var api = Kavenegar.KavenegarApi({
  apikey: "your-apikey",
});
api.SendArray(
  {
    message: '["کاوه نگار", "وب سرویس کاوه نگار"]',
    // sender: '["10008445","10008445"]',
    receptor: '["09123456789","09123456781"]',
  },
  function (response, status) {
    console.log(response);
    console.log(status);
  }
);
