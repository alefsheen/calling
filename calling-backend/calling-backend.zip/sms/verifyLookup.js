var Kavenegar = require("kavenegar");
var api = Kavenegar.KavenegarApi({
  apikey: "your apikey here",
});
api.VerifyLookup(
  {
    receptor: "09361234567",
    token: "852596",
    template: "registerverify",
  },
  function (response, status) {
    console.log(response);
    console.log(status);
  }
);
/*
sample output
{
    "return":
    {
        "status":200,
        "message":"تایید شد"
    },
    "entries": {
            "messageid":8792343,
			"message": "ممنون از ثبت نام شما کد تایید عضویت  : 852596",
            "status":5,
            "statustext":"ارسال به مخابرات",
            "sender":"10004346",
            "receptor":"09361234567",
            "date":1356619709,
            "cost":120
   }    
    
}
*/
