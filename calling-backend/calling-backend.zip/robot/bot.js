const TelegramBot = require("node-telegram-bot-api");
const mongoose = require("mongoose");
const Contact = require("../models/contactModel");
require("dotenv").config();

module.exports = function bot_init() {
  const sendMessageWithOptions = (chatId, text, options) => {
    const defaultOptions = { parse_mode: "markdown" };
    bot.sendMessage(chatId, text, { ...defaultOptions, ...options });
  };

  // Initialize bot
  const bot = new TelegramBot(process.env.BOT_TOKEN, { polling: true });

  // Start command
  bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const userName = msg.from.first_name;
    const userLastName = msg.from.last_name || "";
    const welcomeMessage = `${userName} ${userLastName} عزیز
به بازوی شورا یار خوش آمدید 🙏
این بازو به عنوان مکمل سامانه پیگیری حضور شورا راه اندازی شده است
برای احراز هویت، ابتدا اطلاعات موردنیاز را وارد نمایید.
 `;

    const startOptions = {
      reply_markup: {
        inline_keyboard: [
          createInlineButtons([
            { text: "شروع", callback_data: "signup_start" },
            // { text: "Channels", callback_data: "channels" },
          ]),
        ],
      },
    };

    sendMessageWithOptions(chatId, welcomeMessage, startOptions);
  });

  bot.on("callback_query", async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const data = callbackQuery.data;

    switch (data) {
      case "signup_start":
        bot.sendMessage(chatId, "لطفا شماره تماس خود را وارد کنید");
        break;
    }

    bot.answerCallbackQuery(callbackQuery.id);
  });

  // if (data === "start_signup") {
  //   await Contact.findOneAndUpdate(
  //     { chatId },
  //     { chatId },
  //     { upsert: true, new: true }
  //   );
  //   bot.sendMessage(chatId, "What is your first name?");
  // }

  const steps = ["name", "family", "phone", "profileImage", "group"];
  const groups = ["Group A", "Group B", "Group C"];

  const userSteps = new Map();

  bot.on("message", async (msg) => {
    const chatId = msg.chat.id;
    const userStep = userSteps.get(chatId) || 0;

    const user = await Contact.findOne({ chatId });
    if (!user) {
      return;
    }

    switch (steps[userStep]) {
      case "name":
        await Contact.updateOne({ chatId }, { name: msg.text });
        bot.sendMessage(chatId, "What is your family name?");
        userSteps.set(chatId, userStep + 1);
        break;

      case "family":
        await Contact.updateOne({ chatId }, { family: msg.text });
        bot.sendMessage(chatId, "What is your phone number?");
        userSteps.set(chatId, userStep + 1);
        break;

      case "phone":
        await Contact.updateOne({ chatId }, { phone: msg.text });
        bot.sendMessage(chatId, "Please upload your profile image.");
        userSteps.set(chatId, userStep + 1);
        break;

      case "profileImage":
        if (msg.photo) {
          const fileId = msg.photo[msg.photo.length - 1].file_id;
          const file = await bot.getFile(fileId);
          const filePath = `https://tapi.bale.ai/file/bot${BOT_TOKEN}/${file.file_path}`;
          await Contact.updateOne({ chatId }, { profileImage: filePath });
          const options = groups.map((group) => [
            { text: group, callback_data: group },
          ]);
          bot.sendMessage(chatId, "Select a group:", {
            reply_markup: {
              inline_keyboard: options,
            },
          });
          userSteps.set(chatId, userStep + 1);
        } else {
          bot.sendMessage(chatId, "Please upload a valid profile image.");
        }
        break;

      case "group":
        // This case is handled by callback query when selecting a group
        break;

      default:
        bot.sendMessage(chatId, "All steps are completed. Thank you!");
    }
  });

  bot.on("callback_query", async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const userStep = userSteps.get(chatId);

    if (steps[userStep] === "group") {
      await Contact.updateOne({ chatId }, { group: callbackQuery.data });
      bot.sendMessage(chatId, "All steps are completed. Thank you!");
      userSteps.set(chatId, userStep + 1);
    }
  });

  // Handle errors
  bot.on("polling_error", (error) => {
    console.error(error);
  });

  console.log("Bot is running...");
};
