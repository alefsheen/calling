const TelegramBot = require("node-telegram-bot-api");
const mongoose = require("mongoose");
require("dotenv").config();

module.exports = function bot_init() {
  const bot = new TelegramBot(process.env.BOT_TOKEN, { polling: true });

  const createInlineButtons = (buttons) =>
    buttons.map((button) => ({
      text: button.text,
      callback_data: button.callback_data,
    }));

  const createBackButton = () => [{ text: "بازگشت 🔙", callback_data: "back" }];

  const sendMessageWithOptions = (chatId, text, options) => {
    const defaultOptions = { parse_mode: "markdown" };
    bot.sendMessage(chatId, text, { ...defaultOptions, ...options });
  };

  const editMessageWithOptions = (chatId, messageId, text, options) => {
    const defaultOptions = { parse_mode: "markdown" };
    bot.editMessageText(text, {
      chat_id: chatId,
      message_id: messageId,
      ...defaultOptions,
      ...options,
    });
  };

  bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const userName = msg.from.first_name;
    const userLastName = msg.from.last_name || "";
    const welcomeMessage = `${userName} ${userLastName} عزیز
به بازوی شورا یار خوش آمدید 🙏
این بازو به عنوان مکمل سامانه پیگیری حضور شورا راه اندازی شده است
برای احراز هویت، ابتدا اطلاعات موردنیاز را وارد نمایید.
 `;

    const startOptions = {
      reply_markup: {
        inline_keyboard: [
          createInlineButtons([
            { text: "شروع", callback_data: "signup_start" },
            // { text: "Channels", callback_data: "channels" },
          ]),
        ],
      },
    };

    sendMessageWithOptions(chatId, welcomeMessage, startOptions);
  });

  bot.on("callback_query", (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const messageId = callbackQuery.message.message_id;
    const data = callbackQuery.data;

    switch (data) {
      case "signup_start":
        bot.sendMessage(chatId, "لطفا شماره تماس خود را وارد کنید");
        break;

      case "about_me":
        const amirInfo = `
  *Amir Nobari*
  🎉I'm the founder and developer of the bot.🎉
  For more information, please visit my LinkedIn profile, GitHub profile, or Telegram profile.
  `;
        const inlineKeyboard = [
          [
            { text: "AmirNobari LinkedIn", url: "https://google.com" },
            { text: "AmirNobari GitHub", url: "https://google.com" },
            { text: "AmirNobari Telegram", url: "https://google.com" },
          ],
          createBackButton(),
        ];
        const aboutMeOptions = {
          reply_markup: { inline_keyboard: inlineKeyboard },
        };
        editMessageWithOptions(chatId, messageId, amirInfo, aboutMeOptions);
        break;

      case "channels":
        const channelsOptions = {
          reply_markup: {
            inline_keyboard: [
              createInlineButtons([
                { text: "کانال اصلی", callback_data: "main_channel" },
                { text: "گروه متصل به کانال", callback_data: "related_group" },
              ]),
              createBackButton(),
            ],
          },
        };
        editMessageWithOptions(
          chatId,
          messageId,
          "Choose a channel:",
          channelsOptions
        );
        break;

      case "main_channel":
        const mainChannelOptions = {
          reply_markup: { inline_keyboard: [createBackButton()] },
        };
        editMessageWithOptions(
          chatId,
          messageId,
          "کانال اصلی: [js_challenges](https://t.me/js_challenges)",
          mainChannelOptions
        );
        break;

      case "back":
        const startOptions = {
          reply_markup: {
            inline_keyboard: [
              createInlineButtons([
                { text: "About Me", callback_data: "about_me" },
                { text: "Channels", callback_data: "channels" },
              ]),
            ],
          },
        };
        editMessageWithOptions(
          chatId,
          messageId,
          "به ربات من خوش آمدید 😍",
          startOptions
        );
        break;
    }

    bot.answerCallbackQuery(callbackQuery.id);
  });

  bot.on("photo", async (msg) => {
    // console.log(msg);
    console.log("photo");
    const photo = msg.photo[msg.photo.length - 1];
    console.log({ photo });
    const fileId = photo.file_id;
    console.log({ fileId });

    // Get the file path
    const file = await bot.getFile(fileId);
    console.log({ file });
    const filePath = file.file_path;
    console.log({ filePath });
  });

  bot.on("message", (msg) => {
    // console.log(msg);
    // bot.sendPhoto(
    //   msg.chat.id,
    //   "1532162650:-4158151881739264256:0:77663d7bdd41aa74"
    // );
  });

  console.log("Bot is running...");
};
